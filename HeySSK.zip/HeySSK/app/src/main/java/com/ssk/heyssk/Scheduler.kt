package com.ssk.heyssk

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.Calendar

// Builds and shows the notification.
object Notifier {
    const val CHANNEL = "reminders"

    fun ensureChannel(ctx: Context) {
        val ch = NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH)
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun action(ctx: Context, id: Long, act: String): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, id.toInt(),
            Intent(ctx, AlarmReceiver::class.java).setAction(act).putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    @SuppressLint("MissingPermission")
    fun show(ctx: Context, item: Item) {
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, item.id.toInt(), Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = listOf(item.category, item.location).filter { it.isNotBlank() }.joinToString(" · ")
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(item.title)
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(0, "Done", action(ctx, item.id, AlarmReceiver.ACTION_DONE))
            .addAction(0, "Snooze 10 min", action(ctx, item.id, AlarmReceiver.ACTION_SNOOZE))
            .build()
        val mgr = NotificationManagerCompat.from(ctx)
        if (mgr.areNotificationsEnabled()) mgr.notify(item.id.toInt(), n)
    }
}

// Talks to Android's alarm clock service.
object Scheduler {
    private fun alarmIntent(ctx: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, id.toInt(),
            Intent(ctx, AlarmReceiver::class.java).setAction(AlarmReceiver.ACTION_FIRE).putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun canExact(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    // Ring at an exact moment (falls back to "about then" if exact alarms are not allowed).
    fun setAt(ctx: Context, id: Long, trigger: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = alarmIntent(ctx, id)
        if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
    }

    fun cancelAlarm(ctx: Context, id: Long) {
        ctx.getSystemService(AlarmManager::class.java).cancel(alarmIntent(ctx, id))
    }

    fun cancel(ctx: Context, id: Long) {
        cancelAlarm(ctx, id)
        NotificationManagerCompat.from(ctx).cancel(id.toInt())
    }

    // Set (or remove) the alarm so it matches the item.
    fun schedule(ctx: Context, item: Item) {
        val due = item.dueAt
        if (!item.notify || item.done || due == null) { cancelAlarm(ctx, item.id); return }
        val trigger = due - item.notifyBeforeMin * 60_000L
        if (trigger > System.currentTimeMillis()) setAt(ctx, item.id, trigger) else cancelAlarm(ctx, item.id)
    }

    // For repeating items: the next date after now.
    fun nextDue(item: Item): Long {
        val c = Calendar.getInstance().apply { timeInMillis = item.dueAt ?: System.currentTimeMillis() }
        val lead = item.notifyBeforeMin * 60_000L
        do {
            when (item.repeat) {
                "DAILY" -> c.add(Calendar.DAY_OF_MONTH, 1)
                "WEEKLY" -> c.add(Calendar.DAY_OF_MONTH, 7)
                "MONTHLY" -> c.add(Calendar.MONTH, 1)
                else -> return c.timeInMillis
            }
        } while (c.timeInMillis - lead <= System.currentTimeMillis())
        return c.timeInMillis
    }
}
