package com.ssk.heyssk

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// The list of categories shown in the app.
val CATEGORIES = listOf("Reminders", "Events", "Notes", "To-Do", "Lists", "Birthdays")

// One saved thing (a reminder, an event, a note, a to-do ...). One row in the database.
@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String = "Reminders",
    val location: String = "",
    val dueAt: Long? = null,        // date+time stored as milliseconds; null = no date
    val notify: Boolean = false,    // should we send a notification?
    val notifyBeforeMin: Int = 0,   // 0 = at the time, 60 = 1 hour before, ...
    val repeat: String = "NONE",    // NONE, DAILY, WEEKLY, MONTHLY
    val done: Boolean = false
)

// The DAO lists every question we can ask the database.
@Dao
interface ItemDao {
    @Query("SELECT * FROM items ORDER BY done ASC, CASE WHEN dueAt IS NULL THEN 1 ELSE 0 END, dueAt ASC")
    fun observeAll(): Flow<List<Item>>

    @Query("SELECT * FROM items WHERE id = :id")
    suspend fun get(id: Long): Item?

    @Query("SELECT * FROM items WHERE notify = 1 AND done = 0 AND dueAt IS NOT NULL")
    suspend fun scheduled(): List<Item>

    @Query("SELECT COUNT(*) FROM items")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: Item): Long

    @Delete
    suspend fun delete(item: Item)
}

@Database(entities = [Item::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun itemDao(): ItemDao

    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "heyssk.db")
                .build().also { inst = it }
        }
    }
}
