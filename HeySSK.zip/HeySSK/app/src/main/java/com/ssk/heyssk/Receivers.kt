package com.ssk.heyssk

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// Android calls this when an alarm rings or a notification button is tapped.
class AlarmReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_FIRE = "com.ssk.heyssk.FIRE"
        const val ACTION_DONE = "com.ssk.heyssk.DONE"
        const val ACTION_SNOOZE = "com.ssk.heyssk.SNOOZE"
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        if (id < 0) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.get(ctx).itemDao()
                val item = dao.get(id) ?: return@launch
                when (intent.action) {
                    ACTION_DONE -> {
                        dao.upsert(item.copy(done = true))
                        Scheduler.cancel(ctx, id)
                    }
                    ACTION_SNOOZE -> {
                        NotificationManagerCompat.from(ctx).cancel(id.toInt())
                        Scheduler.setAt(ctx, id, System.currentTimeMillis() + 10 * 60_000L)
                    }
                    else -> {
                        Notifier.show(ctx, item)
                        val trigger = (item.dueAt ?: 0L) - item.notifyBeforeMin * 60_000L
                        // Repeating item: move to the next date (not when it is just a snooze ring).
                        if (item.repeat != "NONE" && trigger <= System.currentTimeMillis() + 60_000L) {
                            val next = item.copy(dueAt = Scheduler.nextDue(item))
                            dao.upsert(next)
                            Scheduler.schedule(ctx, next)
                        }
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }
}

// After the phone restarts all alarms are lost, so we set them again.
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val a = intent.action
        if (a != Intent.ACTION_BOOT_COMPLETED && a != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppDatabase.get(ctx).itemDao().scheduled().forEach { Scheduler.schedule(ctx, it) }
            } finally {
                pending.finish()
            }
        }
    }
}
