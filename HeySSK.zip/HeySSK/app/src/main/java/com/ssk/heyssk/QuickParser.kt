package com.ssk.heyssk

import java.util.Calendar

// Turns a sentence like "remind me to call mom tomorrow 5pm" into title + date + time.
// Pure on-device text rules. No internet, no AI service.
object QuickParser {
    data class Result(val title: String, val category: String, val location: String, val dueAt: Long?)

    private const val MONTHS = "jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec"
    private val I = RegexOption.IGNORE_CASE

    fun parse(input: String): Result {
        var text = input.trim()
        val now = Calendar.getInstance()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        var hasDate = false
        var hasTime = false

        // 1) today / tomorrow
        Regex("""\b(today|tomorrow)\b""", I).find(text)?.let {
            if (it.value.equals("tomorrow", true)) cal.add(Calendar.DAY_OF_MONTH, 1)
            hasDate = true
            text = text.removeRange(it.range)
        }

        // 2) "3 october" or "october 3"
        if (!hasDate) {
            val a = Regex("""\b(\d{1,2})(?:st|nd|rd|th)?\s+($MONTHS)[a-z]*\b""", I).find(text)
            val b = Regex("""\b($MONTHS)[a-z]*\s+(\d{1,2})(?:st|nd|rd|th)?\b""", I).find(text)
            val m = a ?: b
            if (m != null) {
                val day = (if (m === a) m.groupValues[1] else m.groupValues[2]).toInt()
                val mon = MONTHS.split("|").indexOf((if (m === a) m.groupValues[2] else m.groupValues[1]).lowercase().take(3))
                if (day in 1..31 && mon >= 0) {
                    cal.set(cal.get(Calendar.YEAR), mon, day)
                    val startToday = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    }
                    if (cal.before(startToday)) cal.add(Calendar.YEAR, 1) // date already passed: next year
                    hasDate = true
                    text = text.removeRange(m.range)
                }
            }
        }

        // 3) time: "5pm", "5:30 pm", "at 17:30"
        val t12 = Regex("""(?:\bat\s+)?\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b""", I).find(text)
        val t24 = Regex("""\bat\s+(\d{1,2}):(\d{2})\b""", I).find(text)
        if (t12 != null) {
            var h = t12.groupValues[1].toInt()
            val mi = t12.groupValues[2].ifEmpty { "0" }.toInt()
            val pm = t12.groupValues[3].equals("pm", true)
            if (pm && h < 12) h += 12
            if (!pm && h == 12) h = 0
            if (h in 0..23 && mi in 0..59) {
                cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, mi)
                hasTime = true
                text = text.removeRange(t12.range)
            }
        } else if (t24 != null) {
            val h = t24.groupValues[1].toInt()
            val mi = t24.groupValues[2].toInt()
            if (h in 0..23 && mi in 0..59) {
                cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, mi)
                hasTime = true
                text = text.removeRange(t24.range)
            }
        }
        // Only a time was given and it already passed today: use tomorrow.
        if (hasTime && !hasDate && cal.before(now)) cal.add(Calendar.DAY_OF_MONTH, 1)

        // 4) location: "... at Microsoft office"
        var location = ""
        Regex("""\s+at\s+(.+)$""", I).find(text)?.let {
            location = it.groupValues[1].trim()
            text = text.removeRange(it.range)
        }

        // 5) strip "remind me to", and detect the category from the first word
        Regex("""^(please\s+)?(remind me( to)?|reminder( to)?)\s+""", I).find(text)?.let { text = text.removeRange(it.range) }
        var category = "Reminders"
        Regex("""^(event|note|todo|to-do|task|birthday)\b\s*[:\-]?\s*""", I).find(text)?.let {
            category = when (it.groupValues[1].lowercase()) {
                "event" -> "Events"
                "note" -> "Notes"
                "birthday" -> "Birthdays"
                else -> "To-Do"
            }
            text = text.removeRange(it.range)
        }

        // 6) tidy the title
        text = text.replace(Regex("""\s+"""), " ").trim()
            .replace(Regex("""^(on|at|by|to)\s+""", I), "")
            .replace(Regex("""\s+(on|at|by|for)$""", I), "")
            .trim()
        if (text.isBlank()) text = input.trim()
        text = text.replaceFirstChar { it.uppercase() }

        return Result(text, category, location, if (hasDate || hasTime) cal.timeInMillis else null)
    }
}
