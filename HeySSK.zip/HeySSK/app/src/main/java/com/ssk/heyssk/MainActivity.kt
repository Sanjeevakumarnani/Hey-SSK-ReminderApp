@file:OptIn(ExperimentalMaterial3Api::class)

package com.ssk.heyssk

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.ensureChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { HeyTheme { HomeScreen() } }
    }
}

@Composable
fun HeyTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

fun fmt(ms: Long): String = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()).format(Date(ms))

@Composable
fun HomeScreen(vm: MainViewModel = viewModel()) {
    val ctx = LocalContext.current
    val all by vm.items.collectAsStateWithLifecycle()
    var filter by remember { mutableStateOf("All") }
    var editing by remember { mutableStateOf<Item?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var canExact by remember { mutableStateOf(Scheduler.canExact(ctx)) }
    var quick by remember { mutableStateOf("") }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        canExact = Scheduler.canExact(ctx)
        vm.rescheduleAll()
    }

    val shown = all.filter { filter == "All" || it.category == filter }

    Scaffold(
        topBar = { TopAppBar(title = { Text("HEY.SSK") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; showEditor = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add")
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (!canExact) ExactAlarmBanner(ctx)
            OutlinedTextField(
                value = quick,
                onValueChange = { quick = it },
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                placeholder = { Text("Type anything: remind me to call mom tomorrow 5pm") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    if (quick.isNotBlank()) { vm.quickAdd(quick); quick = "" }
                })
            )
            ChipRow(
                options = (listOf("All") + CATEGORIES).map { it to it },
                selected = filter,
                onPick = { filter = it },
                modifier = Modifier.padding(horizontal = 12.dp)
            )
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (shown.isEmpty()) item { Text("Nothing here yet. Tap + or type above.") }
                items(shown, key = { it.id }) { item ->
                    ItemRow(
                        item,
                        onToggle = { vm.toggleDone(item) },
                        onClick = { editing = item; showEditor = true },
                        onDelete = { vm.delete(item) }
                    )
                }
            }
        }
    }

    if (showEditor) {
        EditorDialog(editing, onDismiss = { showEditor = false }, onSave = { vm.save(it); showEditor = false })
    }
}

@Composable
fun ExactAlarmBanner(ctx: Context) {
    Card(
        Modifier.fillMaxWidth().padding(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("Allow exact alarms so reminders arrive on time.")
            TextButton(onClick = {
                if (Build.VERSION.SDK_INT >= 31) {
                    ctx.startActivity(
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
                    )
                }
            }) { Text("Open settings") }
        }
    }
}

@Composable
fun ItemRow(item: Item, onToggle: () -> Unit, onClick: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = item.done, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(
                    item.title,
                    style = MaterialTheme.typography.titleMedium,
                    textDecoration = if (item.done) TextDecoration.LineThrough else null
                )
                val meta = listOfNotNull(
                    item.category,
                    item.dueAt?.let { fmt(it) },
                    item.location.ifBlank { null }
                ).joinToString(" · ")
                Text(meta, style = MaterialTheme.typography.bodySmall)
            }
            if (item.notify && item.dueAt != null) Icon(Icons.Default.Notifications, contentDescription = "Reminder on")
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
        }
    }
}

@Composable
fun ChipRow(
    options: List<Pair<String, String>>,
    selected: String,
    onPick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { (value, label) ->
            FilterChip(selected = selected == value, onClick = { onPick(value) }, label = { Text(label) })
        }
    }
}

@Composable
fun EditorDialog(item: Item?, onDismiss: () -> Unit, onSave: (Item) -> Unit) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(item?.title ?: "") }
    var desc by remember { mutableStateOf(item?.description ?: "") }
    var loc by remember { mutableStateOf(item?.location ?: "") }
    var cat by remember { mutableStateOf(item?.category ?: "Reminders") }
    var due by remember { mutableStateOf(item?.dueAt) }
    var notify by remember { mutableStateOf(item?.notify ?: true) }
    var before by remember { mutableStateOf(item?.notifyBeforeMin ?: 0) }
    var repeat by remember { mutableStateOf(item?.repeat ?: "NONE") }

    // A calendar set to the chosen date/time (or 9:00 today if nothing chosen yet).
    fun cal(): Calendar = Calendar.getInstance().apply {
        if (due != null) timeInMillis = due!! else {
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (item == null) "New item" else "Edit item") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(desc, { desc = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(loc, { loc = it }, label = { Text("Location") }, modifier = Modifier.fillMaxWidth())
                Text("Category")
                ChipRow(CATEGORIES.map { it to it }, cat, { cat = it })
                Text("Date and time")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = {
                        val c = cal()
                        DatePickerDialog(ctx, { _, y, m, d ->
                            val n = cal(); n.set(y, m, d); due = n.timeInMillis
                        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                    }) {
                        Text(due?.let { SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(it)) } ?: "Pick date")
                    }
                    OutlinedButton(onClick = {
                        val c = cal()
                        TimePickerDialog(ctx, { _, h, mi ->
                            val n = cal(); n.set(Calendar.HOUR_OF_DAY, h); n.set(Calendar.MINUTE, mi)
                            n.set(Calendar.SECOND, 0); n.set(Calendar.MILLISECOND, 0); due = n.timeInMillis
                        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
                    }) {
                        Text(due?.let { SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(it)) } ?: "Pick time")
                    }
                    if (due != null) TextButton(onClick = { due = null }) { Text("Clear") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = notify, onCheckedChange = { notify = it })
                    Spacer(Modifier.width(8.dp))
                    Text("Notify me")
                }
                if (notify) {
                    Text("Notify")
                    ChipRow(
                        listOf("0" to "At time", "10" to "10 min before", "60" to "1 hour before", "1440" to "1 day before"),
                        before.toString(), { before = it.toInt() }
                    )
                }
                Text("Repeat")
                ChipRow(
                    listOf("NONE" to "No repeat", "DAILY" to "Daily", "WEEKLY" to "Weekly", "MONTHLY" to "Monthly"),
                    repeat, { repeat = it }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (title.isNotBlank()) {
                    onSave(
                        (item ?: Item(title = "")).copy(
                            title = title.trim(), description = desc.trim(), category = cat,
                            location = loc.trim(), dueAt = due, notify = notify && due != null,
                            notifyBeforeMin = before, repeat = repeat
                        )
                    )
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
