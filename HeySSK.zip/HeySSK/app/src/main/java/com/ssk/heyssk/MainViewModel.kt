package com.ssk.heyssk

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

// Holds the data for the screen and does the saving.
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app
    private val dao = AppDatabase.get(app).itemDao()

    val items = dao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init { viewModelScope.launch { seedFirstRun() } }

    fun save(item: Item) = viewModelScope.launch {
        val newId = dao.upsert(item)
        Scheduler.schedule(ctx, item.copy(id = if (item.id == 0L) newId else item.id))
    }

    fun delete(item: Item) = viewModelScope.launch {
        dao.delete(item)
        Scheduler.cancel(ctx, item.id)
    }

    fun toggleDone(item: Item) = save(item.copy(done = !item.done))

    fun quickAdd(text: String) {
        val r = QuickParser.parse(text)
        save(Item(title = r.title, category = r.category, location = r.location,
            dueAt = r.dueAt, notify = r.dueAt != null))
    }

    fun rescheduleAll() = viewModelScope.launch {
        dao.scheduled().forEach { Scheduler.schedule(ctx, it) }
    }

    // On the very first launch, add your example (you can delete it).
    private suspend fun seedFirstRun() {
        val prefs = ctx.getSharedPreferences("heyssk", Context.MODE_PRIVATE)
        if (prefs.getBoolean("seeded", false)) return
        prefs.edit().putBoolean("seeded", true).apply()
        if (dao.count() > 0) return
        val c = Calendar.getInstance().apply {
            set(Calendar.MONTH, Calendar.OCTOBER); set(Calendar.DAY_OF_MONTH, 3)
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis < System.currentTimeMillis()) c.add(Calendar.YEAR, 1)
        save(Item(title = "GitHub Dev Days", category = "Events", location = "Microsoft office",
            dueAt = c.timeInMillis, notify = true, notifyBeforeMin = 1440))
    }
}
