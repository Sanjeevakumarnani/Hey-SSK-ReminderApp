# HEY.SSK (Step 1 MVP)
Open this folder in Android Studio (File > Open), wait for Gradle sync, press Run.
Fully local: no INTERNET permission, no cloud, no accounts.
